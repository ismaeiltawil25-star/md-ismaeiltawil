# MD Backpack Reader — Icon Pack v2 Integration Directive

## Goal

Replace the current shortcut/application icon with the new v2 icon pack.

This v2 icon intentionally includes a strong blue rounded-square background behind the document so the Windows shortcut icon remains clear on dark desktops and does not appear as a black/fragmented paper outline.

## Attached package contents

Use:

```text
assets/icons/md-backpack-reader.ico
assets/icons/md-backpack-reader-master-1024.png
assets/icons/md-backpack-reader-source-with-background.png
assets/icons/png/md-backpack-reader-16.png
assets/icons/png/md-backpack-reader-24.png
assets/icons/png/md-backpack-reader-32.png
assets/icons/png/md-backpack-reader-48.png
assets/icons/png/md-backpack-reader-64.png
assets/icons/png/md-backpack-reader-128.png
assets/icons/png/md-backpack-reader-256.png
assets/icons/png/md-backpack-reader-512.png
assets/icons/png/md-backpack-reader-1024.png
deployment/windows/resources/md-backpack-reader.rc
deployment/windows/resources/app-icons.qrc
```

## Scope

Replace only the application icon assets and verify the icon in the actual Windows UI.

Do not modify:
- Markdown rendering
- parser flags
- Reader Appearance
- Recent Files
- single-instance routing
- post-processing
- installer behavior except icon reference/rebuild
- frozen `v0.1.0-rc1` portable zip

## Required integration

1. Copy the icon files into the project, preserving paths where possible.
2. Replace the existing `assets/icons/md-backpack-reader.ico` with the v2 multi-size ICO.
3. Ensure the Windows resource file points to the ICO:

```rc
IDI_ICON1 ICON "../../../assets/icons/md-backpack-reader.ico"
```

4. Ensure the Qt resource file includes the same ICO:

```xml
<RCC>
    <qresource prefix="/icons">
        <file alias="md-backpack-reader.ico">../../../assets/icons/md-backpack-reader.ico</file>
    </qresource>
</RCC>
```

5. Ensure `main.cpp` uses:

```cpp
app.setWindowIcon(QIcon(":/icons/md-backpack-reader.ico"));
```

6. Ensure CMake still includes the `.rc` and `.qrc` files for the `md-backpack-reader` target only.

7. If Inno Setup is used, keep or set:

```ini
SetupIconFile=..\..\..\..\assets\icons\md-backpack-reader.ico
UninstallDisplayIcon={app}\md-backpack-reader.exe
```

Adjust the relative path only if the actual `.iss` location differs.

## Required verification

Run:

```powershell
cmake -B build -S . -DCMAKE_PREFIX_PATH="C:\Qt\6.7.0\msvc2019_64"
cmake --build build --config Release --clean-first
ctest --test-dir build -C Release --output-on-failure
.\deployment\windows\package-windows.ps1
```

If rebuilding installer:

```powershell
iscc .\deployment\windows\installer\inno\md-backpack-reader.iss
```

If `iscc` is unavailable in PATH:

```powershell
& "C:\Program Files (x86)\Inno Setup 6\ISCC.exe" .\deployment\windows\installer\inno\md-backpack-reader.iss
```

## Manual Windows UI checks

Confirm visually:

1. `dist/windows/md-backpack-reader/md-backpack-reader.exe` shows the new icon in Windows Explorer.
2. The app window title bar shows the icon.
3. The Windows taskbar shows the icon.
4. If installer is rebuilt:
   - setup exe shows the icon
   - installed app exe shows the icon
   - Start Menu shortcut shows the icon
   - Desktop shortcut shows the icon if selected

## Required output

1. List copied/replaced icon files.
2. Confirm ICO sizes.
3. Report build result.
4. Report CTest result.
5. Report portable packaging result.
6. Report Windows Explorer exe icon verification.
7. Report window/taskbar icon verification.
8. Report installer icon verification if installer is rebuilt.
9. Confirm no unrelated source behavior changed.
10. Confirm frozen `v0.1.0-rc1` zip was not modified.
